Attendance Demo - Glitch Ready
------------------------------

How to run:
1. Sign up at https://glitch.com/ and create a new Node.js project.
2. Upload this folder or files into your new project.
3. The server will run automatically. Glitch provides a public URL.
4. Open the URL on your phone to test 'Mark My Attendance' (allow location access).
5. Open /dashboard to view live records.

Notes:
- CLASS_LOCATION in index.js can be updated to your college coordinates.
- ipapi.co API is used to fetch approximate IP location (may have rate limits).
- For exhibition/demo purposes only.
