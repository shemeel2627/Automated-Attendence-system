import express from "express";
import fs from "fs";
import path from "path";
const app = express();
app.use(express.json());
app.use(express.static("public"));
const PORT = process.env.PORT || 3000;

// campus coordinates
const CLASS_LOCATION = { lat: 10.052, lon: 76.328 };
const ALLOWED_RADIUS = 80; // meters

function distance(lat1, lon1, lat2, lon2) {
  const R = 6371e3;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
            Math.cos(lat1 * Math.PI / 180) *
            Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const DATA_FILE = path.join(process.cwd(), 'attendance.json');

function readData() {
  try {
    if (!fs.existsSync(DATA_FILE)) return [];
    const txt = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(txt || "[]");
  } catch (e) {
    console.error("Error reading data:", e);
    return [];
  }
}

function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

app.post("/checkin", (req, res) => {
  const { name, lat, lon, ip, city } = req.body || {};
  if (typeof lat !== 'number' || typeof lon !== 'number') {
    return res.status(400).json({ error: "Invalid location data" });
  }
  const dist = Math.round(distance(lat, lon, CLASS_LOCATION.lat, CLASS_LOCATION.lon));
  const status = dist <= ALLOWED_RADIUS ? "Present ✅" : "Outside Range ❌";
  const time = new Date().toLocaleString();
  const record = { name: name || "Guest", lat, lon, ip, city, time, status };

  const data = readData();
  data.push(record);
  writeData(data);

  res.json({ message: `Attendance marked as ${status}`, distance: dist });
});

app.get("/dashboard", (req, res) => {
  const data = readData();
  const rows = data.map(r => 
    `<tr><td>${r.name}</td><td>${r.time}</td><td>${r.city || ''}</td><td>${r.status}</td></tr>`
  ).join("");
  res.send(`
    <h2 style="font-family:sans-serif">Admin Dashboard</h2>
    <table border="1" cellpadding="6">
      <tr><th>Name</th><th>Time</th><th>City</th><th>Status</th></tr>
      ${rows}
    </table>
    <p>Total records: ${data.length}</p>
    <p>Refresh to update.</p>
  `);
});

app.listen(PORT, () => console.log("✅ Server running on port " + PORT));
